# UNEX PLAY — projeto Flutter inicial

Aplicativo IPTV em Flutter/Dart para Android e preparação para Android TV. O projeto é organizado por módulos e inclui importação M3U/M3U Plus por URL ou arquivo, busca local, favoritos persistidos e player baseado em `video_player`.

> **Estado real:** esta é a primeira versão funcional de base, não uma versão final certificada. O código foi preparado para validação no GitHub Actions. Não foi possível executar Flutter, compilar APK ou validar streams reais neste ambiente. A reprodução depende das URLs, dos codecs do dispositivo e das permissões do servidor.

## Conteúdo

- `lib/models/`: modelo de conteúdo.
- `lib/services/`: parser M3U, carregamento de playlist e preferências locais.
- `lib/screens/`: catálogo e player.
- `test/`: testes unitários do parser.
- `.github/workflows/android.yml`: pipeline de análise, testes e builds.
- `docs/`: plano de testes e limitações.

## Compilação pelo GitHub usando o celular

1. Crie um repositório vazio no GitHub.
2. Extraia este ZIP e envie todos os arquivos e pastas para a raiz do repositório (incluindo `.github`).
3. Faça commit na branch `main`.
4. Abra a aba **Actions**, selecione **Validar e compilar UNEX PLAY** e aguarde o workflow.
5. Baixe `unex-play-android` em **Artifacts** se todas as etapas passarem.

O workflow gera os arquivos Android padrão do Flutter no runner, pois o ambiente de criação deste pacote não tinha o SDK Flutter instalado. O repositório contém o código-fonte e a automação necessários para esse fluxo. Para compilar localmente, instale Flutter e execute `flutter create --platforms=android --org com.unexplay --project-name unex_play .`, depois `flutter pub get` e `flutter build apk`.

## Fontes IPTV

- A URL deve apontar para uma playlist M3U/M3U Plus, não apenas para um endpoint de vídeo.
- Use apenas playlists e transmissões que você tem autorização para acessar.
- O app guarda a URL da playlist localmente. URLs com credenciais embutidas devem ser tratadas como segredo e não compartilhadas.
- Xtream Codes API ainda não está implementada.

## Player e formatos

O player usa `video_player`, que no Android se apoia no ExoPlayer. HLS (`.m3u8`), MP4 e MPEG-TS dependem da estrutura real da transmissão e dos codecs disponíveis. MPEG-TS direto, URLs sem extensão, RTSP/RTMP e autenticação especial ainda exigem testes em dispositivos reais e podem não funcionar com esta base.

## Segurança

- Não coloque URLs reais com usuário/senha em commits, capturas de tela ou logs.
- A preferência da playlist é armazenada por `shared_preferences`; isso não é um cofre criptográfico. Não use para armazenar credenciais sensíveis sem uma camada de armazenamento seguro.
- O aplicativo não envia os dados da playlist para um serviço de análise.

## Limitações conhecidas da versão inicial

- A organização do catálogo é baseada nos metadados disponíveis na playlist; não há API de filmes/séries, EPG, temporadas/episódios ou retomada persistente.
- A heurística para identificar transmissão ao vivo é simples e precisa ser refinada para fontes com URLs incomuns.
- Os controles do player são básicos; suporte avançado a áudio/legendas, seleção de faixas, buffer configurável e picture-in-picture não foi implementado.
- O layout usa navegação adaptativa e foco Flutter padrão, mas precisa de teste manual com controle remoto em Android TV real.
- O workflow deve ser executado para confirmar resolução de dependências, análise, testes e compilação.

## Android TV

O workflow aplica `tooling/AndroidManifest.xml`, que declara suporte opcional a Leanback e touchscreen não obrigatório, além do launcher de TV. Isso permite que o app seja listado como app de TV em dispositivos compatíveis, mas não certifica a experiência: navegação por D-pad, teclado na busca e telas de diferentes fabricantes ainda precisam de teste real.
